create user 'blogshareuser' @'localhost' identified by 'password';

grant all on *.* to 'blogshareuser'@'localhost';